<?php

namespace App\Filament\Resources\ShoppeeProductRequests\Schemas;

use Filament\Schemas\Schema;
use Filament\Infolists\Components\TextEntry;

class ShoppeeProductRequestInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([

                TextEntry::make('product.productname')
                    ->label('Product'),

                TextEntry::make('quantity'),

                TextEntry::make('total_products'),

                TextEntry::make('total_amount'),

                TextEntry::make('total_pv'),

                TextEntry::make('status')
                    ->badge(),
            ]);
    }
}